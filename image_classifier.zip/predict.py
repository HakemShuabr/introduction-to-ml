# example of test command: python predict.py ./test_images/hard-leaved_pocket_orchid.jpg flower_img_classifier.h5 --top_k 3

from flower_classifier_utils import predict
import numpy as np
import json
import argparse

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

# Import TensorFlow 
import tensorflow as tf
import tensorflow_datasets as tfds
import tensorflow_hub as hub

parser = argparse.ArgumentParser()
parser.add_argument("flower_img", action="store", type=str, help="Path to the flower image to be classified.")
parser.add_argument("flower_classifier", action="store", type=str, help="Path to flower classfier to be used for classificationn.")
parser.add_argument("--top_k", action="store", type=int, default=5, help="The number of L most likely flower types.")
parser.add_argument("--category_names", action="store", type=str, default="./label_map.json", help="The JSON file to map flower labels to their names.")

args = parser.parse_args()

flower_classifier = tf.keras.models.load_model(args.flower_classifier, custom_objects = {"KerasLayer": hub.KerasLayer}, compile=False)

with open(args.category_names, "r") as file:
    class_names = json.load(file)

probs, classes = predict(args.flower_img, flower_classifier, args.top_k)
predicted_flowers = [class_names[str(x+1)].title() for x in classes]

print("\n{} predicted as:".format(args.flower_img))
for i in range(args.top_k):
    print("Label: {}, Name: {}, Probability: {}".format(classes[i], predicted_flowers[i], probs[i]))

