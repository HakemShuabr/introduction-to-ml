import numpy as np
from PIL import Image

# Import TensorFlow 
import tensorflow as tf
import tensorflow_datasets as tfds
import tensorflow_hub as hub

def get_image_np_array(image_path):
    # open the image in the given image path and convert it to numpy array
    
    im = Image.open(image_path)
    return np.asarray(im) 

def process_image(img):
    img_size = 224
    img = tf.convert_to_tensor(img, dtype=tf.float32)
    img = tf.image.resize(img, (img_size, img_size))
    img /= 255
    return img

def predict(image_path, model, top_k):
    # open the image in the given image path and convert it to numpy array
    test_image = get_image_np_array(image_path)
    
    # process the test image
    processed_test_image = process_image(test_image)
    
    # predict the type of the test image
    prediction_prob = model.predict(np.expand_dims(processed_test_image, axis=0))
    
    # Get the top predicted flower types of the image
    probs, idx = tf.nn.top_k(prediction_prob, k=top_k)
    
    probs = list(probs.numpy()[0])
    classes = list(idx.numpy()[0])
    
    return probs, classes